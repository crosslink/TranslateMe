University Research Program for Google Traslate - README.TXT
July 26, 2007
Version 1.0

The most up-to-date documentation is always available at:
http://research.google.com/university/translate/docs.html

