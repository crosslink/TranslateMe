// Copyright 2006 Google Inc. All Rights Reserved.


import com.google.gdata.client.*;
import com.google.gdata.data.*;
import com.google.gdata.data.extensions.*;
import com.google.gdata.util.*;

import com.google.translate.gdata.data.*;

import java.net.*;
import java.io.*;

/**
 * This is an example Translation client which demonstrates how to access the
 * University Research Program for Google Translate's translation interface.  We
 * will show how to make simple translation queries to the translation service
 * and how to access all the information provided.
 *
 * @author jestelle@google.com (Josh Estelle)
 */
public class SimpleClient {

  public static void main(String[] args)
      throws MalformedURLException, IOException, ServiceException {

    // Check for required command line arguments
    if (args.length != 3) {
      System.err.println("Usage: SimpleClient " +
                         "<source language> <target language> " +
                         "<text to translate>\n");
      System.exit(1);
    }

    // Store command line arguments
    String sourceLang      = args[0];
    String targetLang      = args[1];
    String textToTranslate = args[2];

    // Create reader to get login info from user
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    // Get login information
    System.out.print("Login: ");
    String login           = br.readLine();
    System.out.print("Password: ");
    String password        = br.readLine();

    // Create a TranslateService and include information about your
    // application, "companyName-applicationName-versionID"
    TranslateService service = new TranslateService("exampleCo-exampleApp-1");

    // specify the user credentials requesting access
    service.setUserCredentials(login, password);

    // Construct a query for command line arguments
    TranslateQuery query = new TranslateQuery(textToTranslate,
                                              sourceLang,
                                              targetLang);

    // Send the query to the TranslateService returning a TranslateFeed
    TranslateFeed feed = service.query(query, TranslateFeed.class);

    // As long as there's at least one entry
    if (feed.getEntries().size() > 0) {
      // Get the entry
      TranslateEntry entry = feed.getEntries().get(0);

      // Display the translated string with other information
      System.out.println("Feed title:      " + feed.getTitle().getPlainText());
      System.out.println("Feed updated:    " + feed.getUpdated());
      System.out.println("Entry title :    " + entry.getTitle().getPlainText());
      System.out.println("Entry updated:   " + entry.getUpdated());
      System.out.println("Translated Text: " + entry.getText() + "\n\n");
    }
  }

  private SimpleClient() {
    // This doesn't do anything.
    // Utility classes should not have public constructors.
  }
}
