// Copyright 2006 Google Inc. All Rights Reserved.


import com.google.gdata.client.*;
import com.google.gdata.data.*;
import com.google.gdata.data.extensions.*;
import com.google.gdata.util.*;

import com.google.translate.gdata.data.*;

import java.net.*;
import java.io.*;

/**
 * This is an example Translation client which demonstrates how to access the
 * University Research Program for Google Translate's translation interface.
 * We will show how to make detailed translation queries to the translation
 * service and how to access all the information provided.
 *
 * @author jestelle@google.com (Josh Estelle)
 */
public class DetailedClient {

  public static void main(String[] args)
      throws MalformedURLException, IOException, ServiceException {

    // Check for required command line arguments
    if (args.length != 4) {
      System.err.println("Usage: DetailedClient " +
                         "<source language> <target language> " +
                         "<num detailed responses> <text to translate>\n");
      System.exit(1);
    }

    // Store command line arguments
    String sourceLang      = args[0];
    String targetLang      = args[1];
    String numDetailed     = args[2];
    String textToTranslate = args[3];

    // Create reader to get login info from user
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    // Get login information
    System.out.print("Login: ");
    String login           = br.readLine();
    System.out.print("Password: ");
    String password        = br.readLine();

    // Create a TranslateService and include information about your
    // application, "companyName-applicationName-versionID"
    TranslateService service = new TranslateService("exampleCo-exampleApp-1");

    // specify the user credentials requesting access
    service.setUserCredentials(login, password);

    // Construct a query for command line arguments
    TranslateQuery query = new TranslateQuery(textToTranslate,
                                              sourceLang,
                                              targetLang);
    // It's unlikely you'd want to request both detailed translation responses
    // and alignment information, but for purposes of this example code we do
    // both.
    query.setDetailedRequest(numDetailed);
    query.setAlignmentRequest();

    // Send the query to the TranslateService returning a TranslateFeed
    TranslateFeed feed = service.query(query, TranslateFeed.class);

    // For each entry
    for (int i=0; i<feed.getEntries().size(); i++) {
      // Get the entry
      TranslateEntry entry = feed.getEntries().get(i);

      // Display the translated string with other information
      System.out.println("\nEntry title :           " + entry.getTitle().getPlainText());
      System.out.println("Entry updated:          " + entry.getUpdated());
      System.out.println("N-best Translated Text: " + entry.getText());

      // Display the scoring features
      System.out.print("Scoring features:       ");
      for (ScoringFeature feature : entry.getScoringFeatures()) {
        System.out.print(feature.getID() + "=" + feature.getScore() + "  ");
      }
      System.out.print("\n");

      // Display alignment information
      System.out.print("Alignments:             ");
      for (TranslationAlignment alignment : entry.getTranslationAlignments()) {
        System.out.print(alignment.getWord() + " (" + alignment.getPosition() + ")  ");
      }
      System.out.print("\n");
    }
  }

  private DetailedClient() {
    // This doesn't do anything.
    // Utility classes should not have public constructors.
  }
}
